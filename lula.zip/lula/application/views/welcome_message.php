<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
		text-decoration: none;
	}

	a:hover {
		color: #97310e;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}

	#body {
		margin: 0 15px 0 15px;
		min-height: 96px;
	}

	p {
		margin: 0 0 10px;
		padding:0;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}

	/*#864c46:#864c46;
	$white:#ffffff;*/

	@import url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

	* {
	  box-sizing:border-box;
	  margin:0;
	}

	body {
		background: linear-gradient(90deg, #BE8CEF 0%, rgba(61, 46, 232, 0.83) 100%);
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		font-family: 'Montserrat', sans-serif;
	  font-size:10px;
		height: 100vh;
		margin: -20px 0 50px;
	}

	.container {
		background-color: $white;
		border-radius: 5px;
	  	box-shadow: 0 14px 28px rgba(0,0,0,0.25), 
				0 10px 10px rgba(0,0,0,0.22);
		position: relative;
		overflow: hidden;
		width: 768px;
		max-width: 100%;
		min-height: 480px;
	  min-width:370px;
	}

	h2 {
	  font-size:2rem;
	  margin-bottom:1rem;
	}
	.form-container {
	  display:flex;
	}

	.left-container {
	  flex:1;
	  height:480px;
	  background-color:#864c46;
	}
	.right-container {
	  display:flex;
	  flex:1;
	  height:460px;
	  background-color: $white;
	  justify-content:center;
	  align-items:center;
	}

	.left-container {
	  display:flex;
	  flex:1;
	  height:480px;
	  justify-content:center;
	  align-items:center;
	    color:$white;
	}

	.left-container p {
	  font-size:0.9rem;
	}

	.right-inner-container {
	  width:70%;
	  height:80%;
	  text-align:center;
	}

	.left-inner-container {
	  height:50%;
	  width:80%;
	  text-align:center;
	  line-height:22px;
	}

	input, textarea {
		background-color: #eee;
		border: none;
		padding: 12px 15px;
		margin: 8px 0;
		width: 100%;
	  font-size:0.8rem;
	}

	input:focus, textarea:focus{
	  outline:1px solid #864c46;
	}

	button {
		border-radius: 20px;
		border: 1px solid #864c46;
		background-color: #864c46;
		color: #FFFFFF;
		font-size: 12px;
		font-weight: bold;
		padding: 12px 45px;
		letter-spacing: 1px;
		text-transform: uppercase;
		transition: transform 80ms ease-in;
	  cursor:pointer;
	}

	button:hover {
	  opacity:0.7;
	}
	@media only screen and (max-width: 600px) {
	  .left-container{
	    display: none;
	  }
	  .lg-view {
	    display:none;  
	  }
	}

	@media only screen and (min-width: 600px) {
	  .sm-view {
	    display:none;  
	  }
	}

	form p {
	  text-align:left;
	}
	</style>
</head>
<body>

<div class="container">
  <div class="form-container">
    <div class="left-container">
      <!-- <div class="left-inner-container">
      <h2>LULA</h2> -->
      <img src="<?= base_url('/assets/img/test.png')?>" style="width: 100%;">
    <!-- </div> -->
      </div>
    <div class="right-container">
      <div class="right-inner-container">
        <form action="#">
			<h2 class="lg-view">Contact</h2>
      <h2 class="sm-view">Let's Chat</h2>
			<div class="social-container">
				<a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
				<a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
				<a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
			</div>
          <input type="text" placeholder="Name *"  />
      <input type="email" placeholder="Email *" />
			<input type="text" placeholder="Company" />
			<input type="phone" placeholder="Phone" />
			<button>Submit</button>
		</form>
      </div>
    </div>
  </div>
</div>

</body>
</html>
